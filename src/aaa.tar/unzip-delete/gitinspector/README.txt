Copyright © 2012-2015 Ejwa Software. All rights reserved.

This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it under
certain conditions; see the accompanying LICENSE.txt file for further details.

For questions regarding gitinspector you can contact the current maintainer
in charge at gitinspector@ejwa.se.

To run gitinspector; please start it via the gitinspector.py script. Use
the -h or --help flags to get help about available options.

It is also possible to set gitinspector options using the "git config"
command. Refer to the project page at https://github.com/ejwa/gitinspector
for more information.
